import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    
    public static int timStartX = 300;
    public static int timStartY = 200;
    public static int[] level = {0, 0};
    public static boolean endOpen = false;
    public void started()
    {
        Counters.health = 5;
        timStartX = 300;
        timStartY = 200;
        level[0] = 0;
        level[1] = 0;
    }
    public void stopped()
    {
        timStartX = 300;
        timStartY = 200;
        level[0] = 0;
        level[1] = 0;
    }
    public int getTimStartX()
    {
        return timStartX;
    }
    public int getTimStartY()
    {
        return timStartY;
    }
    
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        prepare();
        StartScreen start = new StartScreen();
        addObject(start,300,200);
    }
    
    public void NextLevel()
    {
        Counters.damageCheck = true;
        java.util.List<Actor> list = getObjects(null);
        removeObjects(list);
        prepare();
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        /**
        if (level[0] < 0)
        {
        level[0] = 3;
        }
        else if (level[1] < 0)
        {
        level[1] = 3;
        }
        else if (level[0] > 3)
        {
        level[0] = 0;
        }
        else if (level[1] > 3)
        {
        level[1] = 0;
        }**/
        if ((level[0] == 0)&&(level[1]== 0))
        {
            setBackground​("Station.png");
            Railway railway = new Railway();
            addObject(railway,124,76);
            Railway railway2 = new Railway();
            addObject(railway2,124,345);
            Busker busker = new Busker();
            addObject(busker,414,98);
            //walls first
            Block topwall = new Block(0,0,600,8);
            addObject(topwall,300,4);
            Block leftwall = new Block(0,0,8,400);
            addObject(leftwall,4,200);

            //tim and his health counter
            Tim tim = new Tim();
            addObject(tim,timStartX,timStartY);
            Counters counters = new Counters();
            addObject(counters,50,20);

            //other stuff
            Hazard hazard = new Hazard();
            addObject(hazard,400,300);
        }
        else if ((level[0] == 1)&&(level[1]== 0))
        {
            setBackground​("Station.png");
            //walls first
            Block topwall = new Block(0,0,600,8);
            addObject(topwall,300,4);
            Block rightwall = new Block(592,0,600,400);
            addObject(rightwall,596,200);

            Tim tim = new Tim();
            addObject(tim,timStartX,timStartY);
            Counters counters = new Counters();
            addObject(counters,50,20);

            Simple enemysimple = new Simple(20,3,0);
            addObject(enemysimple, 300, 150);
            Simple enemysimple1 = new Simple(20,3,0);
            addObject(enemysimple1, 300, 250);
        }
        else if ((level[0] == 2)&&(level[1]== 0))
        {
            setBackground​("Fairfield.png");
            //walls first
            Block topwall = new Block(0,0,600,8);
            addObject(topwall,300,4);
            Block rightwall = new Block(592,0,600,400);
            addObject(rightwall,596,200);
            Block leftwall = new Block(0,0,8,400);
            addObject(leftwall,4,200);

            Tim tim = new Tim();
            addObject(tim,timStartX,timStartY);
            Counters counters = new Counters();
            addObject(counters,50,20);

            Key key = new Key();
            addObject(key, 300, 100);
            Complex enemycomplex = new Complex();
            addObject(enemycomplex, 300, 100);
        }
        else if ((level[0] == 3)&&(level[1]== 0))
        {
            setBackground​("Fairfield.png");
            //walls first
            Block topwall = new Block(0,0,600,8);
            addObject(topwall,300,4);
            Block rightwall = new Block(592,0,600,400);
            addObject(rightwall,596,200);
            Block leftwall = new Block(0,0,8,400);
            addObject(leftwall,4,200);
            Block basewallleft = new Block(0,392,200,400);
            addObject(basewallleft,100,396);
            Block basewallright = new Block(400,392,600,400);
            addObject(basewallright,500,396);

            Tim tim = new Tim();
            addObject(tim,timStartX,timStartY);
            Counters counters = new Counters();
            addObject(counters,50,20);
            Simple enemysimple = new Simple(20,3,0);
            addObject(enemysimple, 300, 150);
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        else if ((level[0] == 0)&&(level[1]== 1))
        {
            setBackground​("Station.png");
            Railway railway = new Railway();
            addObject(railway,124,76);
            Railway railway2 = new Railway();
            addObject(railway2,124,345);
            Train train = new Train(90);
            addObject(train,122,208);
            //walls first
            Block leftwall = new Block(0,0,8,400);
            addObject(leftwall,4,200);
            Block basewall = new Block(0,392,600,400);
            addObject(basewall,300,396);

            Tim tim = new Tim();
            addObject(tim,timStartX,timStartY);
            Counters counters = new Counters();
            addObject(counters,50,20);

            Simple enemysimple = new Simple(20,3,0);
            addObject(enemysimple, 200, 200);
        }
        else if ((level[0] == 1)&&(level[1]== 1))
        {
            setBackground​("Station.png");
            //walls first
            Block rightwall = new Block(592,0,600,400);
            addObject(rightwall,596,200);
            Block basewallleft = new Block(0,392,200,400);
            addObject(basewallleft,100,396);
            Block basewallright = new Block(400,392,600,400);
            addObject(basewallright,500,396);

            Tim tim = new Tim();
            addObject(tim,timStartX,timStartY);
            Counters counters = new Counters();
            addObject(counters,50,20);
            Simple enemysimple = new Simple(20,3,0);
            addObject(enemysimple, 300, 150);
        }
        else if ((level[0] == 2)&&(level[1]== 1))
        {
            setBackground​("Fairfield.png");
            //walls first
            Block leftwall = new Block(0,0,8,400);
            addObject(leftwall,4,200);
            Block basewall = new Block(0,392,600,400);
            addObject(basewall,300,396);
            Block rightwallbase = new Block(592,300,600,400);
            addObject(rightwallbase,596,350);
            Block rightwalltop = new Block(592,0,600,100);
            addObject(rightwalltop,596,50);

            Tim tim = new Tim();
            addObject(tim,timStartX,timStartY);
            Counters counters = new Counters();
            addObject(counters,50,20);
            Simple enemysimple = new Simple(20,3,0);
            addObject(enemysimple, 300, 150);
        }
        else if ((level[0] == 3)&&(level[1]== 1))
        {
            setBackground​("Fairfield.png");
            //walls first
            Block rightwall = new Block(592,0,600,400);
            addObject(rightwall,596,200);
            Block leftwallbase = new Block(0,300,8,400);
            addObject(leftwallbase,4,350);
            Block leftwalltop = new Block(0,0,8,100);
            addObject(leftwalltop,4,50);
            Block topwallleft = new Block(0,0,200,8);
            addObject(topwallleft,100,4);
            Block topwallright = new Block(400,0,600,8);
            addObject(topwallright,500,4);

            Tim tim = new Tim();
            addObject(tim,timStartX,timStartY);
            Counters counters = new Counters();
            addObject(counters,50,20);
            Simple enemysimple = new Simple(20,3,0);
            addObject(enemysimple, 300, 150);
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        else if ((level[0] == 0)&&(level[1]== 2))
        {
            setBackground​("Hall.png");
            //walls first
            Block leftwall = new Block(0,0,8,400);
            addObject(leftwall,4,200);
            Block topwall = new Block(0,0,600,8);
            addObject(topwall,300,4);
            Block rightwallbase = new Block(592,300,600,400);
            addObject(rightwallbase,596,350);
            Block rightwalltop = new Block(592,0,600,100);
            addObject(rightwalltop,596,50);

            Tim tim = new Tim();
            addObject(tim,timStartX,timStartY);
            Counters counters = new Counters();
            addObject(counters,50,20);
        }
        else if ((level[0] == 1)&&(level[1]== 2))
        {
            setBackground​("Street.png");
            //walls first
            Block basewall = new Block(0,392,600,400);
            addObject(basewall,300,396);
            Block leftwallbase = new Block(0,300,8,400);
            addObject(leftwallbase,4,350);
            Block leftwalltop = new Block(0,0,8,100);
            addObject(leftwalltop,4,50);
            if (endOpen == false)
            {
                Block leftwall = new Block(0,105,8,295);
                addObject(leftwall,4,200);
            }
            Block topwallleft = new Block(0,0,200,8);
            addObject(topwallleft,100,4);
            Block topwallright = new Block(400,0,600,8);
            addObject(topwallright,500,4);

            Tim tim = new Tim();
            addObject(tim,timStartX,timStartY);
            Counters counters = new Counters();
            addObject(counters,50,20);
            Simple enemysimple = new Simple(20,3,0);
            addObject(enemysimple, 300, 150);
            Simple enemysimple1 = new Simple(20,3,0);
            addObject(enemysimple1, 300, 100);
            Simple enemysimple2 = new Simple(20,3,0);
            addObject(enemysimple2, 300, 200);
        }
        else if ((level[0] == 2)&&(level[1]== 2))
        {
            setBackground​("Street.png");
            //walls first
            Block basewall = new Block(0,392,600,400);
            addObject(basewall,300,396);
            Block topwall = new Block(0,0,600,8);
            addObject(topwall,300,4);

            Tim tim = new Tim();
            addObject(tim,timStartX,timStartY);
            Counters counters = new Counters();
            addObject(counters,50,20);
        }
        else if ((level[0] == 3)&&(level[1]== 2))
        {
            setBackground​("Street.png");
            //walls first
            Block rightwall = new Block(592,0,600,400);
            addObject(rightwall,596,200);
            Block topleftcorner = new Block(0,0,8,8);
            addObject(topleftcorner,4,4);
            Block bottomleftcorner = new Block(0,392,8,400);
            addObject(bottomleftcorner,396,4);

            Tim tim = new Tim();
            addObject(tim,timStartX,timStartY);
            Counters counters = new Counters();
            addObject(counters,50,20);
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        else if ((level[0] == 0)&&(level[1]== 3))
        {
            setBackground​("Hall.png");
            //walls first
            Block leftwall = new Block(0,0,8,400);
            addObject(leftwall,4,200);
            Block basewall = new Block(0,392,600,400);
            addObject(basewall,300,396);
            Block rightwall = new Block(592,0,600,400);
            addObject(rightwall,596,200);

            Tim tim = new Tim();
            addObject(tim,timStartX,timStartY);
            Counters counters = new Counters();
            addObject(counters,50,20);
            CEO ceo = new CEO();
            addObject(ceo,300,350);
        }
        else if ((level[0] == 1)&&(level[1]== 3))
        {
            setBackground​("Norwood.png");
            //walls first
            Block basewall = new Block(0,392,600,400);
            addObject(basewall,300,396);
            Block leftwall = new Block(0,0,8,400);
            addObject(leftwall,4,200);
            Block topwall = new Block(0,0,600,8);
            addObject(topwall,300,4);

            Tim tim = new Tim();
            addObject(tim,timStartX,timStartY);
            Counters counters = new Counters();
            addObject(counters,50,20);
        }
        else if ((level[0] == 2)&&(level[1]== 3))
        {
            setBackground​("Norwood.png");
            //walls first
            Block basewall = new Block(0,392,600,400);
            addObject(basewall,300,396);
            Block topwall = new Block(0,0,600,8);
            addObject(topwall,300,4);

            Tim tim = new Tim();
            addObject(tim,timStartX,timStartY);
            Counters counters = new Counters();
            addObject(counters,50,20);
        }
        else if ((level[0] == 3)&&(level[1]== 3))
        {
            setBackground​("Norwood.png");
            //walls first
            Block basewall = new Block(0,392,600,400);
            addObject(basewall,300,396);
            Block rightwall = new Block(592,0,600,400);
            addObject(rightwall,596,200);
            Block topleftcorner = new Block(0,0,8,8);
            addObject(topleftcorner,4,4);

            Tim tim = new Tim();
            addObject(tim,timStartX,timStartY);
            Counters counters = new Counters();
            addObject(counters,50,20);
        }

        
    }
}
