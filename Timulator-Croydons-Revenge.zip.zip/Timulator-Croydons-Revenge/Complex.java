import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.lang.Math;

/**
 * Write a description of class Complex here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Complex extends Enemy
{
    /**
     * Act - do whatever the Complex wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public int enemyHealth = 20;
    private boolean invincible = false;
    
    public void act()
    {
        World world = getWorld();
        Actor tim = (Actor) world.getObjects(Tim.class).get(0);
        int timX = tim.getX();
        int timY = tim.getY();
        turnTowards​(timX, timY);
        
        //move towards tim
        double angle = Math.toRadians(getRotation());
        int xValue = (int) Math.round (2*Math.cos(angle));
        int yValue = (int) Math.round (2*Math.sin(angle));
        setLocation(getX()+xValue, getY()+yValue);
        Actor weaponTouch = getOneIntersectingObject(Weapon.class);
        if ((weaponTouch != null)&&(invincible == false))
        {
            enemyHealth--;
            invincible = true;
        }
        else
        {
            invincible = false;
        }
        
        //is touching tim? KILL HIM!!
        Actor timTouch = getOneIntersectingObject(Tim.class);
        if (timTouch != null)
        {
            Counters.damageCheck = true;
            MyWorld World = (MyWorld)getWorld();
            Tim.resetCheck = true;
        }
    }
}
