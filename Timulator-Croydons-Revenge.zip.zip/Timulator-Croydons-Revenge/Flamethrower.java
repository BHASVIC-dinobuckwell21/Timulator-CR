import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Flamethrower here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Flamethrower extends Weapon
{
    /**
     * Act - do whatever the Flamethrower wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    private int weaponAngle;
    private int lifetime = 10;
    //Greenfoot.GreenfootImage.scale(int 19,int 85);
    
    public Flamethrower(int angle)
    {
        weaponAngle = angle;
        setRotation(weaponAngle);
    }
    
    public void act()
    {
        World game = getWorld();
        
        
        //timer
        lifetime --;
        if (lifetime == 0)
        {
            game.removeObject(this);
        }
    }
}
