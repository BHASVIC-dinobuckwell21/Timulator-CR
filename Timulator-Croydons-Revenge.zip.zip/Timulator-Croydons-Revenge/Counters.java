import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Counters here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Counters extends Actor
{
    
    protected int x = 0;
    protected GreenfootImage frame = null;
    //the image drawn is centred on its addObject position. the frame filled is centred on the first two values
    public static int health = 5;
    // lives counter
    public static boolean damageCheck = false;
    public static int pickupCheck = 0;
    //causes damage if true
    
    public void loseLife()
    {
        health=health-1;
        if (health <= 0)
        {
            World game = getWorld();
            DeathScreen dead = new DeathScreen();
            game.addObject(dead,300,200);
            Greenfoot.stop();
        }
    }
    public void gainLife(int increase)
    {
        health=health+increase;
    }
    public Counters()
    {
        frame = new GreenfootImage(100,40);
        frame.setColor(Color.BLACK);
        frame.fillRect(0,0,100,40);
        setImage(frame);
    }
    public void setValues (int lives)
    {
        GreenfootImage img = new GreenfootImage (frame);
        img.setColor(Color.RED);
        img.setFont(new Font(true, false, 10));
        img.drawString("It Works!", 65, 35);
    }
    public void act()
    {
        if (damageCheck == true)
        {
            loseLife();
            damageCheck = false;
        }
        if (pickupCheck > 0)
        {
            gainLife(pickupCheck);
            pickupCheck = 0;
        }
        x++;
        GreenfootImage img = new GreenfootImage (frame);
        img.setColor(Color.RED);
        img.setFont(new Font(true, false, 15));
        img.drawString("Health: " + health, 5, 20);
        setImage(img);
    }
}
