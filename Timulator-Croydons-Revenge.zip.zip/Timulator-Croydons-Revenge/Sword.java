import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Sword here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Sword extends Weapon
{
    private int weaponAngle;
    private int lifetime = 5;
    //Greenfoot.GreenfootImage.scale(int 19,int 85);
    
    public Sword(int angle)
    {
        weaponAngle = angle;
        setRotation(weaponAngle);
    }
    public void act()
    {
        World game = getWorld();
        
        
        //timer
        lifetime --;
        if (lifetime == 0)
        {
            game.removeObject(this);
        }

    }
}
