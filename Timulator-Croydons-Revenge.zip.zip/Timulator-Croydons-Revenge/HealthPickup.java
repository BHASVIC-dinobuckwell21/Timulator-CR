import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class HealthPickup here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class HealthPickup extends Actor
{
    /**
     * Act - do whatever the HealthPickup wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public int value = 0;
    public HealthPickup(int health)
    {
        value = health;
    }
    public void act()
    {
        Actor timTouch = getOneIntersectingObject(Tim.class);
        if (timTouch != null)
        {
            MyWorld game = (MyWorld)getWorld();
            Counters.pickupCheck = value;
            game.removeObject(this);
        }
    }
}
