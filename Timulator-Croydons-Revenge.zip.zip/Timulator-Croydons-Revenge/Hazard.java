import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Hazard here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Hazard extends Actor
{
    /**
     * Act - do whatever the Hazard wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    private Counters health;
    
    public void act()
    {
        Actor timTouch = getOneIntersectingObject(Tim.class);
        if (timTouch != null)
        {
            Counters.damageCheck = true;
            MyWorld World = (MyWorld)getWorld();
            Tim.resetCheck = true;
        }
    }
}
