import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Train here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Train extends Enemy
{
    /**
     * Act - do whatever the Train wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public int enemyHealth = 20;
    private boolean invincible = false;
    public Train(int rotation)
    {
        setRotation(rotation);
    }
    public void act()
    {
        MyWorld game = (MyWorld)getWorld();
        Actor timTouch = getOneIntersectingObject(Tim.class);
        if (timTouch != null)
        {
            Counters.damageCheck = true;
            MyWorld World = (MyWorld)getWorld();
            Tim.resetCheck = true;
        }
        
        Actor weaponTouch = getOneIntersectingObject(Weapon.class);
        if ((weaponTouch != null)&&(invincible == false))
        {
            enemyHealth--;
            invincible = true;
        }
        else
        {
            invincible = false;
        }
        if (enemyHealth<=0)
        {
            HealthPickup healthpickup = new HealthPickup(50);
            game.addObject(healthpickup,getX(),getY());
            game.removeObject(this);
        }
        else
        {
        }
    }
}
