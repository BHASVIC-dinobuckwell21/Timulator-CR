import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Gun here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Gun extends Weapon
{
    /**
     * Act - do whatever the Gun wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    private int weaponAngle;
    private int lifetime = 5;
    
    public Gun(int angle)
    {
        weaponAngle = angle;
        setRotation(weaponAngle);
    }
    
    public void act()
    {
        World game = getWorld();
        if ((Projectile.projectileCheck == false))
        {
            Projectile bullet = new Projectile(weaponAngle+90);
            game.addObject(bullet,getX(),getY());
        }
        lifetime --;
        if (lifetime == 0)
        {
            game.removeObject(this);
        }
    }
}
