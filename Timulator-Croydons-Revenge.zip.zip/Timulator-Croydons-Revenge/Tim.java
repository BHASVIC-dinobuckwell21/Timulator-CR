import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Tim here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Tim extends Actor
{
    protected int angle = 0;
    // the angle the weapon points. the image is pointing down
    protected int offsetX = 0;
    protected int offsetY = 0;
    // the distance the weapon will appear away from the player
    protected int weaponCooldown = 100;
    // limits weapon attacks. slowly builds up to allow for longer attacks
    private int weaponType = 1;
    // the weapon equipped currently
    protected boolean notMoving = true;
    // returns whether the player is standing still or not
    public static boolean resetCheck = false;
    //resets tims position if true
    
    /**
     * Act - do whatever the Tim wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void resetPosition()
    {
        MyWorld World = (MyWorld)getWorld();
        setLocation(World.getTimStartX(),World.getTimStartY());
        resetCheck = false;
    }
    
    public void act()
    {
        MyWorld game = (MyWorld)getWorld();
        if (Greenfoot.isKeyDown("1"))
        {
            weaponType = 1;
        }
        else if (Greenfoot.isKeyDown("2"))
        {
            weaponType = 2;
        }
        else if (Greenfoot.isKeyDown("3"))
        {
            weaponType = 3;
        }
        if (resetCheck == true)
        {
            resetPosition();
        }
        else
        {
            //create an instance of game
            
            
            //movement. also adjusts the players facing direction via 'angle', and the weapon offset
            if ((Greenfoot.isKeyDown("up")) && (Greenfoot.isKeyDown("down")))
            {
                notMoving = true;
            }
            else if (Greenfoot.isKeyDown("up"))
            {
                if (Greenfoot.isKeyDown("left"))
                {
                    setLocation​(getX()-4, getY());
                    Actor Block1 = getOneIntersectingObject(Block.class);
                    if (Block1 != null)
                    {
                        setLocation​(getX()+4, getY());
                    }
                    setLocation​(getX(), getY()-4);
                    Actor Block2 = getOneIntersectingObject(Block.class);
                    if (Block2 != null)
                    {
                        setLocation​(getX(), getY()+4);
                    }
                    angle = 135;
                    offsetX = -21;
                    offsetY = -21;
                }
                else if (Greenfoot.isKeyDown("right"))
                {
                    setLocation​(getX()+4, getY());
                    Actor Block1 = getOneIntersectingObject(Block.class);
                    if (Block1 != null)
                    {
                        setLocation​(getX()-4, getY());
                    }
                    setLocation​(getX(), getY()-4);
                    Actor Block2 = getOneIntersectingObject(Block.class);
                    if (Block2 != null)
                    {
                        setLocation​(getX(), getY()+4);
                    }
                    angle = -135;
                    offsetX = 21;
                    offsetY = -21;
                }
                else
                {
                    setLocation​(getX(), getY()-5);
                    Actor Block1 = getOneIntersectingObject(Block.class);
                    if (Block1 != null)
                    {
                        setLocation​(getX(), getY()+5);
                    }
                    offsetX = 0;
                    offsetY = -30;
                    angle = 180;
                }
                notMoving = false;
            }
            else if (Greenfoot.isKeyDown("down"))
            {
                if (Greenfoot.isKeyDown("left"))
                {
                    setLocation​(getX()-4, getY());
                    Actor Block1 = getOneIntersectingObject(Block.class);
                    if (Block1 != null)
                    {
                        setLocation​(getX()+4, getY());
                    }
                    setLocation​(getX(), getY()+4);
                    Actor Block2 = getOneIntersectingObject(Block.class);
                    if (Block2 != null)
                    {
                        setLocation​(getX(), getY()-4);
                    }
                    angle = 45;
                    offsetX = -21;
                    offsetY = 21;
                }
                else if (Greenfoot.isKeyDown("right"))
                {
                    setLocation​(getX()+4, getY());
                    Actor Block1 = getOneIntersectingObject(Block.class);
                    if (Block1 != null)
                    {
                        setLocation​(getX()-4, getY());
                    }
                    setLocation​(getX(), getY()+4);
                    Actor Block2 = getOneIntersectingObject(Block.class);
                    if (Block2 != null)
                    {
                        setLocation​(getX(), getY()-4);
                    }
                    angle = -45;
                    offsetX = 21;
                    offsetY = 21;
                }
                else
                {
                    setLocation​(getX(), getY()+5);
                    Actor Block1 = getOneIntersectingObject(Block.class);
                    if (Block1 != null)
                    {
                        setLocation​(getX(), getY()-5);
                    }
                    offsetX = 0;
                    offsetY = 30;
                    angle = 0;
                }
                notMoving = false;
            }
            else if ((Greenfoot.isKeyDown("left")) && (Greenfoot.isKeyDown("right")))
            {
                notMoving = true;
            }
            else if (Greenfoot.isKeyDown("left"))
            {
                setLocation​(getX()-5, getY());
                Actor Block1 = getOneIntersectingObject(Block.class);
                if (Block1 != null)
                {
                    setLocation​(getX()+5, getY());
                }
                angle = 90;
                offsetX = -30;
                offsetY = 0;
            }
            else if (Greenfoot.isKeyDown("right"))
            {
                setLocation​(getX()+5, getY());
                Actor Block1 = getOneIntersectingObject(Block.class);
                if (Block1 != null)
                {
                    setLocation​(getX()-5, getY());
                }
                angle = -90;
                offsetX = 30;
                offsetY = 0;
            }
            else
            {
                offsetX = 0;
                offsetY = 0;
                notMoving = true;
            }
            
            //weapon checking and setting
            if ((Greenfoot.isKeyDown("space") == true) && (weaponCooldown > 0))
            {
                 weaponCooldown = weaponCooldown - 100;
                 removeTouching​(Weapon.class);
                 if (weaponType == 1)
                 {
                     Sword weapon = new Sword(angle);
                     game.addObject(weapon,getX()+offsetX,getY()+offsetY);
                 }
                 else if (weaponType == 2)
                 {
                     Flamethrower weapon = new Flamethrower(angle);
                     game.addObject(weapon,getX()+(offsetX*3),getY()+(offsetY*3));
                 }
                 else if (weaponType == 3)
                 {
                     Gun weapon = new Gun(angle);
                     game.addObject(weapon,getX(),getY());
                 }
            }
            else if ((Greenfoot.isKeyDown("space") == false) && (weaponCooldown < 0))
            {
                weaponCooldown = weaponCooldown + 5;
            }
            else if ((Greenfoot.isKeyDown("space") == false) && (weaponCooldown < 4000))
            {
                weaponCooldown = weaponCooldown + 10;
            }
            
            // level transition
            if (getX()>595)
            {
                MyWorld.timStartX = 5; 
                MyWorld.timStartY = getY();
                MyWorld.level[0]++;
                game.NextLevel();
            }
            else if (getY()>395)
            {
                MyWorld.timStartX = getX(); 
                MyWorld.timStartY = 5;
                MyWorld.level[1]++;
                game.NextLevel();
            }
            else if (getX()<5)
            {
                MyWorld.timStartX = 595; 
                MyWorld.timStartY = getY();
                MyWorld.level[0]--;
                game.NextLevel();
            }
            else if (getY()<5)
            {
                MyWorld.timStartX = getX(); 
                MyWorld.timStartY = 395;
                MyWorld.level[1]--;
                game.NextLevel();
            }
        }
    }
}
