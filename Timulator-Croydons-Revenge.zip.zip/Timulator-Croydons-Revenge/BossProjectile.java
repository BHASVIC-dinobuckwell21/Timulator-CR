import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class BossProjectile here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BossProjectile extends Enemy
{
    public int enemyHealth = 1;
    private int lifetime = 50;
    
    public void act()
    {
        MyWorld game = (MyWorld)getWorld();
        World world = getWorld();
        Actor tim = (Actor) world.getObjects(Tim.class).get(0);
        int timX = tim.getX();
        int timY = tim.getY();
        turnTowards​(timX, timY);
        
        //move towards tim
        double angle = Math.toRadians(getRotation());
        int xMoveValue = (int) Math.round (5*Math.cos(angle));
        int yMoveValue = (int) Math.round (5*Math.sin(angle));
        setLocation(getX()+xMoveValue, getY()+yMoveValue);
        
        
        //is touching tim? KILL HIM!!
        Actor timTouch = getOneIntersectingObject(Tim.class);
        if (timTouch != null)
        {
            Counters.damageCheck = true;
            game.removeObject(this);
        }
        
        lifetime--;
        if (lifetime <= 0)
        {
            game.removeObject(this);
        }
    }
}
