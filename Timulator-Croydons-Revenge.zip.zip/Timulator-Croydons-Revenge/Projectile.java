import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Projectile here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Projectile extends Actor
{
    /**
     * Act - do whatever the Projectile wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    int direction = 0;
    public static boolean projectileCheck = false;
    
    public Projectile(int angle)
    {
        direction = angle;
        setRotation(direction);
        projectileCheck=true;
    }
    
    public void act()
    {
        World game = getWorld();
        //move
        move(15);
        
        Actor ceoTouch = getOneIntersectingObject(CEO.class);
        if (ceoTouch != null)
        {
            WinScreen end = new WinScreen();
            game.addObject(end,300,200);
            Greenfoot.stop();
        }
        //enemy killer and edge checker because it didnt like it when I had them separate
        Actor enemyTouch = getOneIntersectingObject(Enemy.class);
        if ((enemyTouch != null)||(isAtEdge() == true))
        {
            
            removeTouching​(Enemy.class);
            game.removeObject(this);
            projectileCheck=false;
        }
        else if (isAtEdge() == true)
        {
            game.removeObject(this);
            projectileCheck=false;
        }
        
    }
}
