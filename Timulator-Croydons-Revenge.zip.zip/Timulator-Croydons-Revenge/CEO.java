import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class CEO here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class CEO extends Enemy
{
    /**
     * Act - do whatever the CEO wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    private int spawnCount = 20;
    public int enemyHealth = 50;
    private boolean invincible = false;
    public void act()
    {
        MyWorld game = (MyWorld)getWorld();
        Actor weaponTouch = getOneIntersectingObject(Weapon.class);
        if ((weaponTouch != null)&&(invincible == false))
        {
            enemyHealth--;
            invincible = true;
        }
        else
        {
            invincible = false;
        }
        if (enemyHealth<=0)
        {
            HealthPickup healthpickup = new HealthPickup(1);
            game.addObject(healthpickup,getX(),getY());
            game.removeObject(this);
        }
        
        spawnCount--;
        if (spawnCount <= 0)
        {
            BossProjectile projectileb = new BossProjectile();
            game.addObject(projectileb,getX(),getY());
            spawnCount = 51;
        }
    }
}
